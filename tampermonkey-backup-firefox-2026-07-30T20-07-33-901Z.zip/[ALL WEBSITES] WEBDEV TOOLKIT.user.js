// ==UserScript==
// @name         [ALL WEBSITES] WEBDEV TOOLKIT
// @namespace    http://tampermonkey.net
// @version      1.2
// @description  Press F2 To View!
// @author       The kitty in the wind
// @match        *://*/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_addStyle
// @license      MIT
// ==/UserScript==

//          /\\        /\\      /\\\\\\\\      /\\ /\\         /\\\\\          /\\\\\\\\      /\\         /\\
//          /\\        /\\      /\\            /\    /\\       /\\   /\\       /\\             /\\       /\\
//          /\\   /\   /\\      /\\            /\     /\\      /\\    /\\      /\\              /\\     /\\
//          /\\  /\\   /\\      /\\\\\\        /\\\ /\         /\\    /\\      /\\\\\\           /\\   /\\
//          /\\ /\ /\\ /\\      /\\            /\     /\\      /\\    /\\      /\\                /\\ /\\
//          /\\        /\\      /\\\\\\\\      /\\\\ /\\       /\\\\\          /\\\\\\\\            /\\
//
//    /\\\ /\\\\\\          /\\\\               /\\\\           /\\            /\\   /\\        /\\      /\\\ /\\\\\\
//         /\\            /\\    /\\          /\\    /\\        /\\            /\\  /\\         /\\           /\\
//         /\\          /\\        /\\      /\\        /\\      /\\            /\\ /\\          /\\           /\\
//         /\\          /\\        /\\      /\\        /\\      /\\            /\ /\            /\\           /\\
//         /\\          /\\        /\\      /\\        /\\      /\\            /\\  /\\         /\\           /\\
//         /\\            /\\     /\\         /\\     /\\       /\\            /\\   /\\        /\\           /\\
//         /\\              /\\\\               /\\\\           /\\\\\\\\      /\\     /\\      /\\           /\\

(async function() {
    'use strict';
    // --- MSG Manager ---
    await GM_setValue("TKITW_WDT_mlist", {
        "startmsg": "[WEBDEVTOOLS] Started.",
        "initmsg": "[WEBDEVTOOLS] Finished Initialization.",
        "initmsg2": "[WEBDEVTOOLS] Starting Initialization.",
        "noconfmsg": "[WEBDEVTOOLS] Couldn't Find Configuration, Using Defaults.",
        "dvmonmsg": "[WEBDEVTOOLS] The userscript is running in non-production mode, some features may not work if the setup is wrong."
    });

    async function msgman(midx) {
        const mlist = await GM_getValue("TKITW_WDT_mlist");
        return mlist ? mlist[midx] : "";
    }

    // --- DVM Manager ---
    const dvm = false;
    await GM_setValue("TKITW_WDT_dvm", dvm);
    if (await GM_getValue("TKITW_WDT_dvm")) {
        console.log(await msgman("dvmonmsg"));
    }

    // --- Init Configuration ---
    console.log(await msgman("initmsg2"));

    const defaultConfig = {
        "OPEN_KEY": "F2",
        "PANIC_KEY": "Escape",
        "UI_POS": [0,0],
        "UI_SIZE": [800,600],
        "UI_OPEN": true,
    };

    await GM_setValue("THKITW_WDT_dcnf", defaultConfig);

    let cnf = await GM_getValue("TKITW_WDT_cnf");
    if (!cnf) {
        console.log(await msgman("noconfmsg"));
        cnf = defaultConfig;
        await GM_setValue("TKITW_WDT_cnf", cnf);
    }

    console.log(await msgman("initmsg"));
    // --- Modern CSS UI Styles ---
    GM_addStyle(`
        #wdt-container * { box-sizing: border-box; font-family: 'Segoe UI', system-ui, sans-serif; }
        #wdt-container {
            position: fixed; z-index: 999999;
            background: #11141a; color: #e3e6eb;
            border: 1px solid #2d3139; border-radius: 12px;
            box-shadow: 0 12px 40px rgba(0,0,0,0.5);
            display: flex; flex-direction: column; overflow: hidden;
            user-select: none; min-width: 450px; min-height: 300px;
        }
        #wdt-header {
            background: #1a1f29; padding: 12px 16px;
            display: flex; justify-content: space-between; align-items: center;
            cursor: move; border-bottom: 1px solid #2d3139;
        }
        #wdt-header h3 { margin: 0; font-size: 14px; font-weight: 600; letter-spacing: 0.5px; color: #4f46e5; display: flex; align-items: center; gap: 8px; }
        #wdt-close { background: none; border: none; color: #a3aed0; cursor: pointer; font-size: 18px; }
        #wdt-close:hover { color: #ef4444; }
        #wdt-body { display: flex; flex: 1; height: calc(100% - 45px); }
        #wdt-sidebar { width: 180px; background: #161a23; border-right: 1px solid #2d3139; padding: 12px 8px; display: flex; flex-direction: column; gap: 4px; }
        .wdt-nav-btn {
            background: none; border: none; color: #a3aed0; text-align: left;
            padding: 10px 14px; width: 100%; border-radius: 6px; cursor: pointer;
            font-size: 13px; font-weight: 500; transition: all 0.2s;
        }
        .wdt-nav-btn:hover { background: #222936; color: #fff; }
        .wdt-nav-btn.active { background: #4f46e5; color: #fff; }
        #wdt-content { flex: 1; padding: 20px; overflow-y: auto; background: #11141a; }
        .wdt-panel { display: none; }
        .wdt-panel.active { display: block; }
        .wdt-panel h4 { margin-top: 0; color: #fff; border-bottom: 1px solid #2d3139; padding-bottom: 8px; font-size: 16px; }
        .wdt-row { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; }
        .wdt-row label { font-size: 12px; color: #a3aed0; font-weight: 500; }
        .wdt-row input, .wdt-row select {
            background: #1a1f29; border: 1px solid #2d3139; border-radius: 6px;
            padding: 8px 12px; color: #fff; font-size: 13px; outline: none;
        }
        .wdt-row input:focus { border-color: #4f46e5; }
        .wdt-btn {
            background: #4f46e5; color: #fff; border: none; padding: 10px 16px;
            border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; transition: background 0.2s;
        }
        .wdt-btn:hover { background: #4338ca; }
        .wdt-btn-secondary { background: #2d3139; color: #e3e6eb; margin-left: 8px;}
        .wdt-btn-secondary:hover { background: #3f4450; }
        .wdt-card { background: #1a1f29; border: 1px solid #2d3139; border-radius: 8px; padding: 14px; margin-bottom: 12px; }
        .wdt-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-top: 10px; }
        .wdt-stat-box { background: #161a23; padding: 12px; border-radius: 6px; text-align: center; border: 1px solid #2d3139; }
        .wdt-stat-val { font-size: 18px; font-weight: 700; color: #4f46e5; margin-top: 4px; }
    `);
    // --- Build DOM Elements ---
    const container = document.createElement('div');
    container.id = 'wdt-container';
    container.style.left = `${cnf.UI_POS[0]}px`;
    container.style.top = `${cnf.UI_POS[1]}px`;
    container.style.width = `${cnf.UI_SIZE[0]}px`;
    container.style.height = `${cnf.UI_SIZE[1]}px`;
    container.style.display = cnf.UI_OPEN ? 'flex' : 'none';

    container.innerHTML = `
        <div id="wdt-header">
            <h3>WEBDEV TOOLKIT V1.2</h3>
            <button id="wdt-close">✕</button>
        </div>
        <div id="wdt-body">
            <div id="wdt-sidebar">
                <button class="wdt-nav-btn active" data-target="panel-dash">Dashboard</button>
                <button class="wdt-nav-btn" data-target="panel-tools">Quick Tools</button>
                <button class="wdt-nav-btn" data-target="panel-config">Configuration</button>
            </div>
            <div id="wdt-content">
                <!-- Dashboard Panel -->
                <div id="panel-dash" class="wdt-panel active">
                    <h4>Overview</h4>
                    <div class="wdt-card">
                        <p style="margin:0; font-size: 14px; color: #a3aed0;">Active Core Environment node details.</p>
                        <div class="wdt-grid">
                            <div class="wdt-stat-box"><div>Host</div><div class="wdt-stat-val" style="font-size:12px; word-break:break-all;">${window.location.hostname}</div></div>
                            <div class="wdt-stat-box"><div>DVM Mode</div><div class="wdt-stat-val">${dvm ? 'ON' : 'OFF'}</div></div>
                            <div class="wdt-stat-box"><div>Hotkeys</div><div class="wdt-stat-val" id="dash-open-key">${cnf.OPEN_KEY}</div></div>
                        </div>
                    </div>
                </div>

                <!-- Quick Tools Panel -->
                <div id="panel-tools" class="wdt-panel">
                    <h4>Developer Utilities</h4>
                    <div class="wdt-card">
                        <p style="margin-top:0; font-size:13px; color:#a3aed0;">Manipulate the document lifecycle context instantly.</p>
                        <button class="wdt-btn" id="tool-reload">Force Reload</button>
                        <button class="wdt-btn wdt-btn-secondary" id="tool-clear-storage">Clear Local Storage</button>
                    </div>
                </div>

                <!-- Config Panel -->
                <div id="panel-config" class="wdt-panel">
                    <h4>Toolkit Engine Configuration</h4>
                    <div class="wdt-row">
                        <label>Action Window Toggle Key</label>
                        <input type="text" id="cfg-open-key" value="${cnf.OPEN_KEY}">
                    </div>
                    <div class="wdt-row">
                        <label>Emergency Panic Break Key</label>
                        <input type="text" id="cfg-panic-key" value="${cnf.PANIC_KEY || ''}" placeholder="e.g. Escape">
                    </div>
                    <div style="margin-top: 20px;">
                        <button class="wdt-btn" id="cfg-save-btn">Save Configurations</button>
                        <button class="wdt-btn wdt-btn-secondary" id="cfg-reset-btn">Reset Defaults</button>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(container);
    // --- UI State Actions & Controls ---
    const toggleUI = () => {
        const isHidden = container.style.display === 'none';
        container.style.display = isHidden ? 'flex' : 'none';
        cnf.UI_OPEN = isHidden;
        GM_setValue("TKITW_WDT_cnf", cnf);
    };

    // Global Key Listener for Toggle and Panic features
    window.addEventListener('keydown', (e) => {
        if (e.key === cnf.OPEN_KEY) {
            e.preventDefault();
            toggleUI();
        }
        if (cnf.PANIC_KEY && e.key === cnf.PANIC_KEY) {
            container.style.display = 'none';
            container.remove();
            cnf.UI_OPEN = false;
            GM_setValue("TKITW_WDT_cnf", cnf);

        }
    });

    document.getElementById('wdt-close').addEventListener('click', toggleUI);

    // Tab Navigation Switcher Logic
    const navButtons = container.querySelectorAll('.wdt-nav-btn');
    const panels = container.querySelectorAll('.wdt-panel');

    navButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            navButtons.forEach(b => b.classList.remove('active'));
            panels.forEach(p => p.classList.remove('active'));

            btn.classList.add('active');
            container.querySelector(`#${btn.dataset.target}`).classList.add('active');
        });
    });
    // --- Config Save / Reset Actions ---
    document.getElementById('cfg-save-btn').addEventListener('click', async () => {
        cnf.OPEN_KEY = document.getElementById('cfg-open-key').value.trim() || "F2";
        cnf.PANIC_KEY = document.getElementById('cfg-panic-key').value.trim() || null;

        await GM_setValue("TKITW_WDT_cnf", cnf);
        document.getElementById('dash-open-key').innerText = cnf.OPEN_KEY;
        alert("Configuration updated successfully!");
    });

    document.getElementById('cfg-reset-btn').addEventListener('click', async () => {
        if(confirm("Reset all Toolkit properties to default factory states?")) {
            cnf = defaultConfig;
            await GM_setValue("TKITW_WDT_cnf", cnf);
            document.getElementById('cfg-open-key').value = cnf.OPEN_KEY;
            document.getElementById('cfg-panic-key').value = cnf.PANIC_KEY || '';
            document.getElementById('dash-open-key').innerText = cnf.OPEN_KEY;
            container.style.width = `${cnf.UI_SIZE[0]}px`;
            container.style.height = `${cnf.UI_SIZE[1]}px`;
        }
    });

    // --- Core Dev Tools Action Handlers ---
    document.getElementById('tool-reload').addEventListener('click', () => window.location.reload());
    document.getElementById('tool-clear-storage').addEventListener('click', () => {
        localStorage.clear();
        sessionStorage.clear();
        alert("Local and Session browser structures dropped.");
    });

    // --- Draggable Window Logic Structure ---
    const header = document.getElementById('wdt-header');
    let isDragging = false, startX, startY, initialLeft, initialTop;

    header.addEventListener('mousedown', (e) => {
        if (e.target.id === 'wdt-close') return;
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        initialLeft = container.offsetLeft;
        initialTop = container.offsetTop;
        document.addEventListener('mousemove', dragWindow);
        document.addEventListener('mouseup', dropWindow);
    });

    function dragWindow(e) {
        if (!isDragging) return;
        const newLeft = initialLeft + (e.clientX - startX);
        const newTop = initialTop + (e.clientY - startY);
        container.style.left = `${newLeft}px`;
        container.style.top = `${newTop}px`;
    }

    async function dropWindow() {
        isDragging = false;
        document.removeEventListener('mousemove', dragWindow);
        document.removeEventListener('mouseup', dropWindow);
        cnf.UI_POS = [container.offsetLeft, container.offsetTop];
        await GM_setValue("TKITW_WDT_cnf", cnf);
    }
})();
