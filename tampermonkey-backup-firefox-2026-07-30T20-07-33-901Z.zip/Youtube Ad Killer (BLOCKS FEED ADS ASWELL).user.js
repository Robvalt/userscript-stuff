// ==UserScript==
// @name         Youtube Ad Killer (BLOCKS FEED ADS ASWELL)
// @namespace    http://tampermonkey.net/
// @version      2026-07-25
// @description  deletes all youtube ads (feed ads and video ads)
// @author       The kitty in the wind
// @match        http*://*.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// @run-at       document-start
// @downloadURL https://update.greasyfork.org/scripts/588692/Youtube%20Ad%20Killer%20%28BLOCKS%20FEED%20ADS%20ASWELL%29.user.js
// @updateURL https://update.greasyfork.org/scripts/588692/Youtube%20Ad%20Killer%20%28BLOCKS%20FEED%20ADS%20ASWELL%29.meta.js
// ==/UserScript==

(function() {
    'use strict';

    function handleNewElement(element) {
        console.log("ad found, removing")
        element.remove();
    }

    const observer = new MutationObserver((mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) {
                        if (node.matches('.ytd-in-feed-ad-layout-renderer')) {
                            handleNewElement(node);
                        }
                        node.querySelectorAll('.ytd-in-feed-ad-layout-renderer').forEach(handleNewElement);
                    }
                });
            }
        }
    });

    const checkBody = setInterval(() => {
        if (document.body) {
            clearInterval(checkBody);
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        }
    }, 10);

    var ytInitialPlayerResponse = null;

    function getter() {
        return ytInitialPlayerResponse;
    }

    function setter(data) {
        ytInitialPlayerResponse = { ...data, adPlacements: [] };
    }

    if (window.ytInitialPlayerResponse) {
        Object.defineProperty(window.ytInitialPlayerResponse, 'adPlacements', {
            get: () => [],
            set: (a) => undefined,
            configurable: true
        });
    } else {
        Object.defineProperty(window, 'ytInitialPlayerResponse', {
            get: getter,
            set: setter,
            configurable: true
        });
    }

    const { fetch: origFetch } = window;
    window.fetch = async (...args) => {
        const response = await origFetch(...args);
        if (response.url.includes('/youtubei/v1/player')) {
            const text = () =>
                response
                    .clone()
                    .text()
                    .then((data) => data.replace(/adPlacements/, 'odPlacement'));
            response.text = text;
            return response;
        }
        return response;
    };

    setInterval(function() {
        try {
            const btn = document.querySelector('.videoAdUiSkipButton,.ytp-ad-skip-button,.ytp-skip-ad-button');
            if (btn) {
                btn.click();
            }
            const ad = document.querySelector('.ad-showing,.ad-interrupting');
            if (ad) {
                const video = document.querySelector('video');
                if (video) video.playbackRate = 16;
            }
        } catch (ex) {}
    }, 100);

    setInterval(function() {
        try {
            const div = document.querySelector('#player-ads');
            if (div) {
                div.remove();
            }
        } catch (ex) {}
    }, 500);
})();
